<?php
require_once('helper/helper.php');
if (!auth_check()):
    return redirect('login.php');
endif;

$query = "SELECT COUNT(*) AS `total` FROM pokemon";
$result = $con->query($query);
$total = $result->fetch_object()->total;
$limit = 16;
$active = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = (isset($_GET['page']) && $_GET['page'] > 1) ? (int)$_GET['page'] * $limit - $limit : 0;
$pages = ceil($total / $limit);

if ($pages < $active):
    return redirect('pokedex.php');
endif;

$pokemons = [];
$query = "SELECT LPAD(p.id, 3, '000') AS `no`, p.name, x.types 
        FROM pokemon p, (
            SELECT a.pokemon_id, GROUP_CONCAT(b.name ORDER BY a.order) AS `types` 
            FROM pokemon_types a JOIN types b ON a.type_id = b.id 
            GROUP BY a.pokemon_id
        ) x 
        WHERE x.pokemon_id = p.id
        ORDER BY p.id
        LIMIT ?, ?";
$stmt = $con->prepare($query);
$stmt->bind_param("ii", $start, $limit);
$result = $stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_object()):
    $pokemons[] = $row;
endwhile;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kanto Pokédex</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/pokemon-type.css">
    <script src="vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</head>
<body class="bg-dark">
    <nav class="navbar fixed-top navbar-expand-md navbar-dark bg-dark pt-2 pb-2 navbar-border">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <span class="title">Pokédex</span>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item link">
                        <a class="nav-link" href="index.php" title="Home">
                            <i class="fas fa-home"></i>
                        </a>
                    </li>
                    <li class="nav-item link">
                        <a class="nav-link active" href="pokedex.php">
                            Pokémon List
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?= strtoupper(auth_user()->username) ?> <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Sign Out
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4 mb-5" id="main">
        <div class="row">
        <?php
            foreach ($pokemons as $p):
        ?>
            <div class="col-md-3">
                <div class="card mb-3">
                    <figure class="img-pokemon">
                        <a href="detail.php?id=<?= htmlentities((int)$p->no) ?>">
                            <img class="card-img-top" src="image/pokemon/<?= htmlentities($p->no) ?>.png">
                        </a>
                    </figure>
                    <div class="card-body pokemon-info">
                        <small class="number">#<?= htmlentities($p->no) ?></small>
                        <h4 class="card-title"><?= htmlentities($p->name) ?></h4>
                        <?php 
                            $types = explode(',', $p->types);
                            foreach ($types as $t):
                                $temp = strtolower($t);
                        ?>
                            <div class="type">
                                <span class="background-color-<?= $temp ?>"><?= htmlentities($t); ?></span>
                            </div>
                        <?php 
                            endforeach;
                        ?>
                    </div>
                </div>
            </div>
        <?php 
            endforeach;
        ?>
        </div>
        <nav class="m-3">
            <ul class="pagination justify-content-center">
            <?php 
                for ($i = 1; $i <= $pages; $i++):
            ?>
                <li class="page-item <?= ($i == $active) ? 'active' : '' ?>">
                    <a class="page-link" href="pokedex.php?page=<?= $i ?>"><?= $i ?></a>
                </li>
            <?php 
                endfor;
            ?>
                </li>
            </ul>
        </nav>
    </div>
</body>
</html>
