<?php
require_once('helper/helper.php');
auth_destroy();
redirect('index.php');
