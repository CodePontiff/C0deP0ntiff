<?php

$config = [
    'server' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'anp_case3',
];

$con = new mysqli($config['server'], $config['username'], $config['password'], $config['database']);
