<?php
require_once('helper/helper.php');
if (!auth_check()):
    return redirect('login.php');
endif;

if (!isset($_GET['id'])):
    return redirect('pokedex.php');
endif;

$id = $_GET['id'];
$pokemon = null;
$query = "SELECT LPAD(p.id, 3, '000') AS `no`, p.name, x.types, p.species, p.description 
        FROM pokemon p, (
            SELECT a.pokemon_id, GROUP_CONCAT(b.name ORDER BY a.order) AS `types` 
            FROM pokemon_types a JOIN types b ON a.type_id = b.id 
            WHERE a.pokemon_id = ?
            GROUP BY a.pokemon_id
        ) x 
        WHERE x.pokemon_id = p.id AND p.id = ?
        ORDER BY p.id
        LIMIT 1";
$stmt = $con->prepare($query);
$stmt->bind_param("ii", $id, $id);
$result = $stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows != 1):
    return redirect('pokedex.php');
endif;
$pokemon = $result->fetch_object();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kanto Pokédex</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/pokemon-type.css">
    <script src="vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</head>
<body class="bg-dark">
    <nav class="navbar fixed-top navbar-expand-md navbar-dark bg-dark pt-2 pb-2 navbar-border">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <span class="title">Pokédex</span>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item link">
                        <a class="nav-link" href="index.php" title="Home">
                            <i class="fas fa-home"></i>
                        </a>
                    </li>
                    <li class="nav-item link">
                        <a class="nav-link" href="pokedex.php">
                            Pokémon List
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?= strtoupper(auth_user()->username) ?> <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Sign Out
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4 mb-5" id="main">
       <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <h3>
                        <?= htmlentities($pokemon->name) ?>
                        <span class="number-detail">#<?= htmlentities($pokemon->no) ?></span>
                    </h3>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <img class=" img-pokemon img-fluid" src="image/pokemon/<?= htmlentities($pokemon->no) ?>.png">
                    </div>
                    <div class="col-md-6">
                        <div class="card-text">
                            <div class="type-container">
                                <div class="type-info">Type</div>
                                <div class="type">
                            <?php 
                                $types = explode(',', $pokemon->types);
                                foreach ($types as $t):
                                    $temp = strtolower($t);
                            ?>
                                    <span class="background-color-<?= strtolower($temp) ?>"><?= htmlentities($t); ?></span>
                            <?php 
                                endforeach;
                            ?>
                                </div>
                            </div>
                            <br><br>
                            <div class="information">
                                <div class="species"><?= htmlentities($pokemon->species) ?></div>
                                <div class="description"><?= htmlentities($pokemon->description) ?></div>
                            </div>
                            <div class="pokeball text-center">
                                <img src="image/pokeball.png" class=" img-pokeball">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       </div>
    </div>
</body>
</html>
