<?php

require_once('helper/auth.php');
require_once('helper/message.php');
require_once('helper/csrf.php');
require_once('helper/connect.php');

function dd($dd)
{
    echo "<pre>";
    print_r($dd);
    echo "</pre>";
    die();
}

function redirect($url)
{
    header("Location: $url");
    die();
}
