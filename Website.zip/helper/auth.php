<?php

function auth_store($auth)
{
    $_SESSION['auth'] = $auth;
}

function auth_destroy()
{
    unset($_SESSION['auth']);
}

function auth_check()
{
    return isset($_SESSION['auth']);
}

function auth_user()
{
    return (auth_check()) ? $_SESSION['auth'] : null;
}
