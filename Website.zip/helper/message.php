<?php

function has_error()
{
    return isset($_SESSION['error']);
}

function add_error($error)
{
    $_SESSION['error'] = $error;
}

function get_error()
{
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
    return $error;
}
