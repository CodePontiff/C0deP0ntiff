<?php

session_start();
session_regenerate_id(true);

function csrf_token()
{
    if (!csrf_exists()):
        $_SESSION['_token'] = bin2hex(random_bytes(32));
    endif;
    return $_SESSION['_token'];
}

function csrf_field()
{
    $token = csrf_token();
    return "<input type='hidden' name='_token' value='$token'>";
}

function validate_token($token)
{
    return csrf_exists() && $token === csrf_token();
}

function csrf_exists()
{
    return isset($_SESSION['_token']);
}
