<?php
require_once('helper/helper.php');
if (auth_check()):
    return redirect('index.php');
endif;

if (strtoupper($_SERVER['REQUEST_METHOD']) == "POST"):
    $_token = (isset($_REQUEST['_token'])) ? $_REQUEST['_token'] : '';
    if (validate_token($_token)):
        $username = (isset($_REQUEST['username'])) ? $_REQUEST['username'] : '';
        $password = (isset($_REQUEST['password'])) ? sha1($_REQUEST['password']) : '';
        if (empty(trim($username))):
            add_error('The username field must be filled');
        elseif (empty(trim($password)) || sha1('') == $password):
            add_error('The password field must be filled');
        endif;
        if (has_error()):
            return redirect('login.php');
        endif;
        $query = "SELECT * FROM `users` WHERE username = ? LIMIT 1";
        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows == 1):
            $row = $result->fetch_object();
            $hash_password = $row->password;
            if (password_verify($password, $hash_password)):
                auth_store($row);
                return redirect('index.php');
            endif;
        endif;
        return redirect('login.php');
    endif;
endif;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Page</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/login.css">
    <script src="vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/md5.min.js"></script>
</head>
<body>
    <div class="main">
        <div class="card card-container">
            <img class="profile-img-card" src="image/pokeball.png">
            <form class="form-signin" method="POST" autocomplete="off">
                <?= csrf_field() ?>
                <input type="text" name="username" class="form-component form-control" placeholder="Username" required autofocus>
                <input type="password" name="password" class="form-component form-control" placeholder="Password" required>
                <button class="form-component btn btn-lg btn-primary btn-block btn-signin" type="submit">Sign in</button>
            <?php
                if (has_error()):
            ?>
	            <div class="error bg-danger"><?= get_error() ?></div>
            <?php
                endif;
            ?>
            </form>
        </div>
    </div>
    <script>
        (function($) {
            $('form').submit(function() {
                var el = $("input[name='password']"),
                    pass = el.val(),
                    md5 = MD5(pass);
                el.val(md5);
            });
        })($);
    </script>
</body>
</html>
